/**********************************************************************
Implementation file for the checkers and space classes.
Written by Jacob Handley
Last edited 4/16/2017
**********************************************************************/

#include "game.h"
#include "checkers.h"
#include "colors.h"
#include <queue>
#include <iostream>
using namespace std;
namespace main_savitch_14{

checkers::checkers(){
	int i;
	int j;
	for(i = 0; i < 3; i++){
		for(j = 0; j < 8; j++){
			if(i%2 != j%2)
				board[i][j].fill();
		}
	}
	for(i = 5; i < 8; i++){
		for(j = 0; j < 8; j++){
			if(i%2 != j%2){
				board[i][j].fill();
				board[i][j].make_red();
			}
		}
	}
	reds = 12;
	whites = 12;
}
	
void checkers::restart(){
	checkers();
}

void checkers::display_status()const{
	cout<<"    A     B     C     D     E     F     G     H  "<<endl;
	for(int i = 0; i < 8; i++){
		if(i%2 == 0)
			cout<<WHITE<<" |"<<B_RED<<"      "<<B_BLACK
			<<"      "<<B_RED<<"      "<<B_BLACK<<"      "
			<<B_RED<<"      "<<B_BLACK<<"      "<<B_RED
			<<"      "<<B_BLACK<<"      "<<RESET<<"|"<<endl;
		else
			cout<<WHITE<<" |"<<B_BLACK<<"      "<<B_RED
			<<"      "<<B_BLACK<<"      "<<B_RED<<"      "
			<<B_BLACK<<"      "<<B_RED<<"      "<<B_BLACK
			<<"      "<<B_RED<<"      "<<RESET<<"|"<<endl;
		cout<<i+1<<"|";
		for(int j = 0; j < 8; j++){
			if(i%2 == j%2) cout<<B_RED;
			else cout<<B_BLACK;
			if(board[i][j].isempty())
				cout<<"      ";
			else if(board[i][j].isking()){
				if(board[i][j].isred())
					cout<<RED<<"  @@  ";
				else cout<<WHITE<<"  @@  ";
			}
			else{
				if(board[i][j].isred())
					cout<<RED<<"  @   ";
				else cout<<WHITE<<"  @   ";
			}
		}//for j loop
		cout<<RESET<<WHITE<<"|"<<endl;
		if(i%2 == 0)
			cout<<WHITE<<" |"<<B_RED<<"      "<<B_BLACK
			<<"      "<<B_RED<<"      "<<B_BLACK<<"      "
			<<B_RED<<"      "<<B_BLACK<<"      "<<B_RED
			<<"      "<<B_BLACK<<"      "<<RESET<<"|"<<endl;
		else
			cout<<WHITE<<" |"<<B_BLACK<<"      "<<B_RED
			<<"      "<<B_BLACK<<"      "<<B_RED<<"      "
			<<B_BLACK<<"      "<<B_RED<<"      "<<B_BLACK
			<<"      "<<B_RED<<"      "<<RESET<<"|"<<endl;
	}//for i loop
}

bool checkers::is_legal(const string& move)const{
	int j = int(tolower(move[0]) - 'a');
	int i = int(move[1] - '1');
	int y = int(tolower(move[2]) - 'a');
	int x = int(move[3] - '1');
	if(jump(i, j, x, y))
		return 1;
	if(has_jump())
		return 0;
	if(board[i][j].isking()){
		if((x == i+1 || x == i-1) && (y == j+1 || y == j-1) && board[x][y].isempty() && 0<=x<8 && 0<=y<8){
			if(board[i][j].isred() && next_mover() == HUMAN)
				return 1;
			else if(!board[i][j].isred() && next_mover() == COMPUTER)
				return 1;
		}
	}
	else if(board[i][j].isred() && next_mover() == HUMAN && !board[i][j].isempty()){
		if((x == i-1 && (y == j+1 || y == j-1)) && board[x][y].isempty() && 0<=x<8 && 0<=y<8)
			return 1;
	}
	else if(!board[i][j].isred() && !board[i][j].isempty() && next_mover() == COMPUTER){
		if((x == i+1 && (y == j+1 || y == j-1)) && board[x][y].isempty() && 0<=x<8 && 0<=y<8)
			return 1;
	}
	return 0;
}

void checkers::make_move(const string& move){
	int first = 0;
	int second = 1;
	int third = 2;
	int fourth = 3;
	do{
		int j = int(tolower(move[first]) - 'a');
		int i = int(move[second] - '1');
		int y = int(tolower(move[third]) - 'a');
		int x = int(move[fourth] - '1');
		bool red = board[i][j].isred();
		bool king = board[i][j].isking();
		if(jump(i, j, x, y)){
			int a = (i+x)/2;
			int b = (j+y)/2;
			if(board[a][b].isred()) reds--;
			else whites--;
			board[a][b].make_empty();
		}
		board[i][j].make_empty();
		board[x][y].fill();
		if(red) board[x][y].make_red();
		if(king) board[x][y].make_king();
		if(board[x][y].isred() && x == 0)
			board[x][y].make_king();
		else if(!board[x][y].isred() && x == 7)
			board[x][y].make_king();
		first += 2;
		second += 2;
		third += 2;
		fourth += 2;
	}while(fourth <= move.length());
	game::make_move(move);
}

bool checkers::jump(int i, int j, int x, int y)const{
	int a = (i+x)/2;
	int b = (j+y)/2;
	if(board[i][j].isempty())
		return 0;
	if(board[i][j].isking()){
		if((x == i+2 || x == i-2) && (y == j+2 || y == j-2) && board[x][y].isempty() && !board[a][b].isempty() && 0<=x<8 && 0<=y<8){
			if(board[i][j].isred() && next_mover() == HUMAN && !board[a][b].isred())
				return 1;
			else if(!board[i][j].isred() && next_mover() == COMPUTER && board[a][b].isred())
				return 1;
		}
	}
	else if(board[i][j].isred() && next_mover() == HUMAN && !board[a][b].isred()){
		if((x == i-2 && (y == j+2 || y == j-2)) && board[x][y].isempty() && !board[a][b].isempty() && 0<=x<8 && 0<=y<8)
			return 1;
	}
	else if(next_mover() == COMPUTER && board[a][b].isred() && !board[i][j].isred()){
		if((x == i+2 && (y == j+2 || y == j-2)) && board[x][y].isempty() && !board[a][b].isempty() && 0<=x<8 && 0<=y<8)
			return 1;
	}
	return 0;
}

bool checkers::has_jump()const{
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			if(board[i][j].isred() && next_mover() == HUMAN){
				if(board[i][j].isking()){
					if((board[i+2][j+2].isempty() && !board[i+1][j+1].isempty() && !board[i+1][j+1].isred() && i<6 && j<6) || (board[i+2][j-2].isempty() && !board[i+1][j-1].isempty() && !board[i+1][j-1].isred() && i<6 && 2<=j) || (board[i-2][j+2].isempty() && !board[i-1][j+1].isempty() && !board[i-1][j+1].isred() && i>=2 && j<6) || (board[i-2][j-2].isempty() && !board[i-1][j-1].isempty() && !board[i-1][j-1].isred() && i>=2 && 2<=j))
						return 1;
				}//red king if
				else{
					if((board[i-2][j+2].isempty() && !board[i-1][j+1].isempty() && !board[i-1][j+1].isred() && i>=2 && j<6) || (board[i-2][j-2].isempty() && !board[i-1][j-1].isempty() && !board[i-1][j-1].isred() && i>=2 && 2<=j))
						return 1;
				}//red regular if
			}//red pieces if
			else if(!board[i][j].isred() && !board[i][j].isempty() && next_mover() == COMPUTER){
				if(board[i][j].isking()){
					if((board[i+2][j+2].isempty() && !board[i+1][j+1].isempty() && board[i+1][j+1].isred() && i<6 && j<6) || (board[i+2][j-2].isempty() && !board[i+1][j-1].isempty() && board[i+1][j-1].isred() && i<6 && 2<=j) || (board[i-2][j+2].isempty() && !board[i-1][j+1].isempty() && board[i-1][j+1].isred() && 2<=i && j<6) || (board[i-2][j-2].isempty() && !board[i-1][j-1].isempty() && board[i-1][j-1].isred() && 2<=i && 2<=j))
						return 1;
				}//white king if
				else{
					if((board[i+2][j+2].isempty() && !board[i+1][j+1].isempty() && board[i+1][j+1].isred() && i<6 && j<6) || (board[i+2][j-2].isempty() && !board[i+1][j-1].isempty() && board[i+1][j-1].isred()) && i<6 && 2<=j)
						return 1;
				}//white regular if
			}//white pieces if
		}//for j loop
	}//for i loop
	return 0;
}

void checkers::make_human_move(){
	string move;
	move = get_user_move();
	while(!is_legal(move)){
		display_message("Illegal move. \n");
		move = get_user_move();
	}
	make_move(move);
}

string checkers::get_user_move()const{
	string answer;
	if(game::get_move_number() == 0){
		display_message("Enter move in the format 'a6b5'. \n");
		display_message("To make a multiple jump, 'a6c4e2'. \n");
	}
	display_message("Your move, please: ");
	getline(cin, answer);
	return answer;
}

bool checkers::is_game_over()const{
	if(reds == 0 || whites == 0)
		return 1;
	else
		return 0;
}

game::who checkers::winning()const{
	if(whites > reds)
		return COMPUTER;
	else if(reds > whites)
		return HUMAN;
	else
		return NEUTRAL;
}

game* checkers::clone()const{
	return new checkers(*this);
}

void checkers::compute_moves(queue<string>& moves)const{
	string newmove = "    ";
	char one, three;
	int two, four;
	for(one = 'a'; one < 'i'; one++){
		for(two = '1'; two < '9'; two++){
			for(three = 'a'; three < 'i'; three++){
				for(four = '1'; four < '9'; four++){
					newmove[0] = one;
					newmove[1] = two;
					newmove[2] = three;
					newmove[3] = four;
					if(is_legal(newmove))
						moves.push(newmove);
				}
			}
		}
	}
}

int checkers::evaluate()const{
	int wkings = 0;
	int rkings = 0;
	for(int i = 0; i < 8; i++){
		for(int j = 0; j < 8; j++){
			if(!board[i][j].isred() && board[i][j].isking())
				wkings++;
			else if(board[i][j].isred() && board[i][j].isking())
				rkings++;
		}
	}
	return wkings + whites - reds - rkings;
}

space::space(){
	is_red = false;
	is_empty = true;
	is_king = false;
}

void space::fill(){
	is_empty = false;
}

void space::make_red(){
	is_red = true;
}

void space::make_empty(){
	is_empty = true;
	is_red = false;
	is_king = false;
}

void space::make_king(){
	is_king = true;
}

bool space::isred()const{
	return is_red;
}

bool space::isempty()const{
	return is_empty;
}

bool space::isking()const{
	return is_king;
}
}//namespace
