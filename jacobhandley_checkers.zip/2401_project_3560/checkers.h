/***********************************************************************
This file creates two class, space and checkers, that are used to make
a two-player checkers game. Space creates the board and stores
information about each piece, and checkers handles the logic of the 
game. Many functions in checkers are derived from the author's game 
class.
Written by Jacob Handley
Last edited 4/16/2017
***********************************************************************/

#include "game.h"
#include <queue>

#ifndef CHECKERS_H
#define CHECKERS_H
namespace main_savitch_14{

class space{
	public:
		space();
		void fill();
		void make_red();
		void make_empty();
		void make_king();
		bool isred()const;
		bool isempty()const;
		bool isking()const;

	private:
		bool is_red;
		bool is_empty;
		bool is_king;
};

class checkers: public game{
	public:
		checkers();
		void restart();
		void display_status()const;
		bool is_legal(const std::string& move)const;
		void make_move(const std::string& move);
		bool jump(int i, int j, int x, int y)const;
		bool has_jump()const;
		void make_human_move();
		std::string get_user_move()const;
		bool is_game_over()const;
		game::who winning()const;
		game* clone()const;
		void compute_moves(std::queue<std::string>& moves)const;
		int evaluate()const;
		void make_real();
		void make_unreal();

	private:
		space board[8][8];
		int reds;
		int whites;
};
}//namespace


#endif
