#include "checkers.h"
#include "game.h"
#include "colors.h"
#include <iostream>
using namespace main_savitch_14;
using namespace std;

int main(){
	checkers mine;
	mine.play();

	return 0;
}
