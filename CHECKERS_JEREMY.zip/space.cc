//****************************
// Jeremy Beauchamp
// CS 2401 Project 6
// Checkers Part 1
// Space class
// space.cc
//****************************

#include "space.h"

using namespace std;

//constructor
Space :: Space(){
	playable = false;
	red = false;
	black = false;
	red_piece = false;
	black_piece = false;
	king = false;
}

//accessors
bool Space :: is_playable() const{
	return playable;
}

bool Space :: is_empty() const{
	if(! red_piece && ! black_piece){
		return true;
	}
	else{
		return false;
	}
}

bool Space :: is_red() const{
	return red;
}

bool Space :: is_black() const{
	return black;
}

bool Space :: has_red_piece() const{
	if(red_piece && ! king){
		return true;
	}
	else{
		return false;
	}
}

bool Space :: has_black_piece() const{
	if(black_piece && ! king){
		return true;
	}
	else{
		return false;
	}
}

bool Space :: has_red_king() const{
	if(red_piece && king){
		return true;
	}
	else{
		return false;	
	}
}

bool Space :: has_black_king() const{
	if(black_piece && king){
		return true;
	}
	else{
		return false;	
	}
}

//mutators
void Space :: set_playable(bool x){
	playable = x;
}

void Space :: set_empty(){
	black_piece = false;
	red_piece = false;
	king = false;
}

void Space :: set_red(){
	red = true;
}

void Space :: set_black(){
	black = true;
}

void Space :: add_red_piece(){
	red_piece = true;
}

void Space :: add_black_piece(){
	black_piece = true;
}

void Space :: set_king(){
	red_piece = true;
	king = true;
}
