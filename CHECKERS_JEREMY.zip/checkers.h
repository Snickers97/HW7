//**********************
// Jeremy Beauchamp
// CS 2401 Project 6
// Checkers Part 1
// Checkers Class
// checkers.h
//**********************

#ifndef CHECKERS_H
#define CHECKERS_H

#include <iostream>
#include <string>

#include "game.h"
#include "space.h"
#include "colors.h"

class Checkers : public main_savitch_14 :: game{
    public:
        //constructor
        Checkers();

        void display_status() const;
        
        void restart();

	int num_red() const;

        int num_black() const;
        
        bool is_valid(const std :: string& move) const;

        bool single_move_valid(const string& move) const;

        bool jump_valid(const string& move) const;
        
        bool second_jump_valid(const string& move) const;
    
        bool double_jump_valid(const string& move) const;

        bool is_legal(const std :: string& move) const;

        void make_move(const std :: string& move);

        bool is_game_over() const;

	game* clone() const;

        void compute_moves(std::queue<std::string>& moves) const;

        int evaluate() const;

        who winning() const;
    
    
    private:
        Space board[8][8];

        //conversions
        string to_upper(const std :: string& s) const;
        int to_int(char c) const;
        char to_char(int x) const;
        char to_char_num(int x) const;
        void convert_move(const string& s, int& a, int& b, int& c, int& d) const;
        string to_move(int a, int b, int c, int d) const;
};

#endif

