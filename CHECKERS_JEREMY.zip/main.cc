#include "checkers.h"
#include "space.h"
#include "game.h"
#include "colors.h"
#include <iostream>

using namespace std;

int main(){
	Checkers a;
	a.play();
}
