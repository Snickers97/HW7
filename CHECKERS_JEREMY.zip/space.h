//***********************
// Jeremy Beauchamp
// CS 2401 Project 6
// Checkers Part 1
// Space class
// space.h
//***********************

#ifndef SPACE_H
#define SPACE_H

class Space{
	public:
		//constructor
		Space();

		//accessors
		bool is_playable() const;		
		bool is_empty() const;
		bool is_red() const;
		bool is_black() const;
		bool has_red_piece() const;
		bool has_black_piece() const;
		bool has_red_king() const;
		bool has_black_king() const;
		
		//mutators
		void set_playable(bool x);
		void set_empty();
		void set_red();
		void set_black();
		void add_red_piece();
		void add_black_piece();
		void set_king();
		
		
	private:
		bool playable;
		bool red;
		bool black;
		bool red_piece;
		bool black_piece;
		bool king;
		
};

#endif
