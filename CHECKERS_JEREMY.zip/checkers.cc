//*********************
// Jeremy Beauchamp
// CS 2401 Project 6
// Checkers Part 1
// Checkers class
// checkers.cc
//*********************

#include "checkers.h"

using namespace std;

const char PIECE = 'O';
const char KING = 'X';

//private helper functions
string Checkers :: to_upper(const string& s) const{
    string move = s;
    
    int a = ('A' - 'a');
    if(move[0] >= 'a' && move[0] <= 'z'){
        move[0] += a;
    }
    
    if(move[2] >= 'a' && move[2] <= 'z'){
        move[2] += a;
    }
    
    return move;
}

int Checkers :: to_int(char c) const{
    switch(c){
        case 'A':
            return 0;
            break;
        case 'B':
            return 1;
            break;
        case 'C':
            return 2;
            break;
        case 'D':
            return 3;
            break;
        case 'E':
            return 4;
            break;
        case 'F':
            return 5;
            break;
        case 'G':
            return 6;
            break;
        case 'H':
            return 7;
            break;
        case '0':
            return 0;
            break;
        case '1':
            return 1;
            break;
        case '2':
            return 2;
            break;
        case '3':
            return 3;
            break;
        case '4':
            return 4;
            break;
        case '5':
            return 5;
            break;
        case '6':
            return 6;
            break;
        case '7':
            return 7;
            break;
        case '8':
            return 8;
            break;
        case '9':
            return 9;
            break;
        default:
            break;
    }
}

char Checkers :: to_char(int x) const{
    switch(x){
        case 0:
            return 'A';
            break;
        case 1:
            return 'B';
            break;
        case 2:
            return 'C';
            break;
        case 3:
            return 'D';
            break;
        case 4:
            return 'E';
            break;
        case 5:
            return 'F';
            break;
        case 6:
            return 'G';
            break;
        case 7:
            return 'H';
            break;
        default:
            break;
    }
}

char Checkers :: to_char_num(int x) const{
    switch(x){
        case 0:
            return '0';
            break;
        case 1:
            return '1';
            break;
        case 2:
            return '2';
            break;
        case 3:
            return '3';
            break;
        case 4:
            return '4';
            break;
        case 5:
            return '5';
            break;
        case 6:
            return '6';
            break;
        case 7:
            return '7';
            break;
        default:
            break;
    }
}

void Checkers :: convert_move(const string& s, int& a, int& b, int& c, int& d) const{
    string copy = to_upper(s);

    b = to_int(copy[0]);
    a = to_int(copy[1]) - 1;
    
    d = to_int(copy[2]);
    c = to_int(copy[3]) - 1;
}

string Checkers :: to_move(int a, int b, int c, int d) const{
    string s = "    ";

    s[0] = to_char(b);
    s[1] = to_char_num(a) + 1;
    s[2] = to_char(d);
    s[3] = to_char_num(c) + 1;
    return s;
}

//constrctor
Checkers :: Checkers(){
    //colors the board and sets playability
    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if((j + i) % 2 == 0){
                board[i][j].set_black();
                board[i][j].set_playable(true);
            }
            else{
                board[i][j].set_red();
                board[i][j].set_playable(false);
            }
        }
    }

    //adds pieces
    for(int i = 0; i < 3; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].is_playable()){
                board[i][j].add_black_piece();
            }
        }
    }

    for(int i = 5; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].is_playable()){
                board[i][j].add_red_piece();
            }
        }
    }
}

//prints board to screen
void Checkers :: display_status() const{
    cout << endl;
    //prints letters for the columns and adds dashes on top of board
    cout << "       A      B      C      D      E      F      G      H" << endl;
    cout << "   ";
    for(int x = 0; x < 58; ++x){
        cout << '-';
    }
    cout << endl;

    for(int i = 0; i < 8; ++i){
        //this loop repeats the line 3 times so it looks better
        //and makes sure pieces are printed in the middle of the spaces
        for(int a = 0; a < 3; ++a){        
            //prints row numbers
            if(a == 1){
                cout << " " << i + 1 << " |";
            }            
            else{
                cout << "   |";
            }
    
            for(int j = 0; j < 8; ++j){
                //if space is red, no possible pieces
                if(board[i][j].is_red()){
                    cout << B_RED << "       " << RESET;
                }
                //if space is black
                else if(board[i][j].is_black()){
                    if(a == 1){
                        if(board[i][j].is_empty()){
                            cout << B_BLACK << "       " << RESET;
                        }
                        else if(board[i][j].has_black_piece()){
                            cout << B_BLACK << WHITE << "   " << PIECE //
                            << "   " << RESET;
                        }
                        else if(board[i][j].has_black_king()){
                            cout << B_BLACK << WHITE << "   " << KING //
                            << "   " << RESET;
                        }
                        else if(board[i][j].has_red_piece()){
                            cout << B_BLACK << RED << "   " << PIECE //
                            << "   " << RESET;
                        }
                        else if(board[i][j].has_red_king()){
                            cout << B_BLACK << RED << "   " << KING //
                            << "   " << RESET;
                        }
                    }
                    else{
                        cout << B_BLACK << "       " << RESET;
                    }
                }
            }
            if(a == 1){
                cout << "| " << i + 1 << endl;
            }
            else{
                cout << "| " << endl;
            }        
        }
    }
    //prints dashes at bottom and displays letters for columns
    cout << "   ";
    for(int x = 0; x < 58; ++x){
        cout << '-';
    }
    cout << endl;
    cout << "       A      B      C      D      E      F      G      H" << endl;
    cout << endl;
}

//resets to original set up
void Checkers :: restart(){
    //colors the board and sets playability
    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if((j + i) % 2 == 0){
                board[i][j].set_black();
                board[i][j].set_playable(true);
            }
            else{
                board[i][j].set_red();
                board[i][j].set_playable(false);
            }
        }
    }

    //adds pieces
    for(int i = 0; i < 3; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].is_playable()){
                board[i][j].add_black_piece();
            }
        }
    }

    for(int i = 5; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].is_playable()){
                board[i][j].add_red_piece();
            }
        }
    }
}

int Checkers :: num_red() const{
    int red = 0;    

    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].has_red_piece() || board[i][j].has_red_king()){
                ++red;
            }
        }
    }
    return red;
}

int Checkers :: num_black() const{
    int black = 0;    

    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].has_black_piece() || board[i][j].has_black_king()){
                ++black;
            }
        }
    }
    return black;
}
/*
//old is_legal()
bool Checkers :: is_legal(const std :: string& move) const{
    string s;    
    s = to_upper(move);    
    
    if(s == "B6A5" || s == "B6C5" || s == "D6C5" || s == "D6E5" || s == "F6E5" //
    || s == "F6G5" || s == "H6G5"){
        return true;
    }
    else{
        return false;
    }
}
*/

//checks if move is within bound of board
bool Checkers :: is_valid(const string& move) const{
    int a, b, c, d;    
    string s = move;
    convert_move(s, a, b, c, d);

    if((a >= 0 && a < 8) && (b >= 0 && b < 8) && (c >= 0 && c < 8) && (d >= 0 && d < 8)){
        return true;
    }
    else{
        return false;
    }
}

bool Checkers :: single_move_valid(const string& move) const{
    int a, b, c, d;
    string s;
    s = move;

    convert_move(s, a, b, c, d);

    if(! is_valid(s)){
        return false;
    }

    if(next_mover() == HUMAN){
        if(board[a][b].has_red_piece()){    
            if((c == a - 1 && d == b + 1) || (c == a - 1 && d == b - 1)){
                return true;
            }
        }
    
        else if(board[a][b].has_red_king()){
            if((c == a + 1 && d == b + 1) || (c == a - 1 && b - 1)){
                return true;
            }
        }
    
    }
    else if(next_mover() == COMPUTER){
        if(board[a][b].has_black_piece()){
            if((c == a + 1 && d == b + 1) || (c == a + 1 && d == b - 1)){
                return true;
            }
        }
        
        else if(board[a][b].has_black_king()){
            if((c == a - 1 && d == b + 1) || (c == a - 1 && d == b - 1)){
                return true;
            }
        }
    }
    else{
        return false;
    }
}

bool Checkers :: jump_valid(const string& move) const{
    int a, b, c, d;
    string s;
    s = move;
    
    convert_move(s, a, b, c, d);

    if(! is_valid(s)){
        return false;
    }

    if(next_mover() == HUMAN){
        if((board[a][b].has_red_piece() || board[a][b].has_red_king()) && board[c][d].is_empty()){
            if(((a - 1) == (c + 1)) && ((b + 1) == (d - 1))){
                if(board[a - 1][b + 1].has_black_piece() || board[a - 1][b + 1].has_black_king()){
                    return true;
                }        
            }
            else if(((a - 1) == (c + 1)) && ((b - 1) == (d + 1))){
                if(board[a - 1][b - 1].has_black_piece() || board[a - 1][b - 1].has_black_king()){
                    return true;
                }
            }    
            else if(board[a][b].has_red_king()){
                if(((a + 1) == (c - 1)) && ((b - 1) == (d + 1))){
                    if(board[a + 1][b - 1].has_black_piece() || board[a + 1][b - 1].has_black_king()){
                        return true;
                    }
                }
                else if(((a + 1) == (c - 1)) && ((b + 1) == (d - 1))){
                    if(board[a + 1][b + 1].has_black_piece() || board[a + 1][b - 1].has_black_king()){
                        return true;
                    }
                }
            }
        }
    }
    else{
        if((board[a][b].has_black_piece() || board[a][b].has_black_king()) && board[c][d].is_empty()){
            if(((a + 1) == (c - 1)) && ((b + 1) == (d - 1))){
                if(board[a + 1][b + 1].has_red_piece() || board[a + 1][b + 1].has_red_king()){
                    return true;
                }
            }
            else if(((a + 1) == (c - 1)) && ((b - 1) == (d + 1))){
                if(board[a + 1][b - 1].has_red_piece() || board[a + 1][b - 1].has_red_king()){
                    return true;
                }
            }
            else if(board[a][b].has_black_king()){
                if(((a - 1) == (c + 1)) && ((b + 1) == (d - 1))){
                    if(board[a - 1][b - 1].has_red_piece() || board[a + 1][b - 1].has_red_king()){
                        return true;
                    }
                }
                else if(((a - 1) == (c + 1)) && ((b - 1) == (d + 1))){
                    if(board[a - 1][b - 1].has_red_piece() || board[a - 1][b - 1].has_red_king()){
                        return true;
                    }
                }
            }
        }
    }
    

    return false;
}

bool Checkers :: second_jump_valid(const string& move) const{
    int a, b, c, d;
    string s, s2;
    s = move;

    convert_move(s, a, b, c, d);

    if(! is_valid(s)){
        return false;
    }

    if(next_mover() == HUMAN){
        if(board[a][b].is_empty() && board[c][d].is_empty()){
            if(((a - 1) == (c + 1)) && ((b + 1) == (d - 1))){
                if(board[a - 1][b + 1].has_black_piece() || board[a - 1][b + 1].has_black_king()){
                    return true;
                }        
            }
            else if(((a - 1) == (c + 1)) && ((b - 1) == (d + 1))){
                if(board[a - 1][b - 1].has_black_piece() || board[a - 1][b - 1].has_black_king()){
                    return true;
                }
            }    
        }
    }
    else{
        if(board[a][b].is_empty() && board[c][d].is_empty()){
            if(((a + 1) == (c - 1)) && ((b + 1) == (d - 1))){
                if(board[a + 1][b + 1].has_red_piece() || board[a + 1][b + 1].has_red_king()){
                    return true;
                }
            }
            else if(((a + 1) == (c - 1)) && ((b - 1) == (d + 1))){
                if(board[a + 1][b - 1].has_red_piece() || board[a + 1][b - 1].has_red_king()){
                    return true;
                }
            }
        }
    }
    

    
}

bool Checkers :: double_jump_valid(const string& move) const{
    int a, b, c, d, e, f;
    string s, s2;
    s = move;
    
    convert_move(s, a, b, c, d);

    if(! is_valid(s)){
        return false;
    }

    if(next_mover() == HUMAN){
        if(board[a][b].has_red_piece()){
            if((c == a - 4) && (d == b)){
                e = a - 2;
                f = b - 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
                e = a -2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            
            }
            else if((c == a - 4) && (d == b + 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
            else if((c == a - 4) && (d == b - 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
        }
        else if(board[a][b].has_red_king()){
            if((c == a - 4) && (d == b)){
                e = a + 2;
                f = b - 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
                e = a + 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            
            }
            else if((c == a + 4) && (d == b + 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
            else if((c == a + 4) && (d == b - 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
        }
    }
    else{
        if(board[a][b].has_black_piece()){
            if((c == a + 4) && (d == b)){
                e = a + 2;
                f = b - 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
                e = a + 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            
            }
            else if((c == a + 4) && (d == b + 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
            else if((c == a + 4) && (d == b - 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
        }
        else if(board[a][b].has_black_king()){
            if((c == a - 4) && (d == b)){
                e = a - 2;
                f = b - 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
                e = a -2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            
            }
            else if((c == a - 4) && (d == b + 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
            else if((c == a - 4) && (d == b - 4)){
                e = a - 2;
                f = b + 2;
                s2 = to_move(a, b, e, f);
                if(jump_valid(s2)){
                    s2 = to_move(e, f, c, d);
                    if(second_jump_valid(s2)){
                        return true;
                    }
                }
            }
        }
    }
}

//checks if a move is legal
bool Checkers :: is_legal(const string& move) const{
    int a, b, c, d;    
    string s = move;
    
    if(! is_valid(s)){
        return false;
    }

    convert_move(s, a, b, c, d);

    if(! board[a][b].is_playable() || ! board[c][d].is_playable()){
        return false;
    }

    if(board[a][b].is_empty() || ! board[c][d].is_empty()){
        return false;
    }

    if(! single_move_valid(s)){
        if(! jump_valid(s)){
            if(! double_jump_valid(s)){
                return false;
            }
        }
    }

    return true;    
}

//executes a move
void Checkers :: make_move(const std :: string& move){
    //converts string to original and new positions and flips them to
    //correct order to be used as array indices
    int a, b, c, d, e, f;    
    string s, s2, s3;
    s = to_upper(move);    
    
    convert_move(s, a, b, c, d);
    if(next_mover() == HUMAN){
        if(board[a][b].has_red_piece() || board[a][b].has_red_king()){
            if(single_move_valid(s) && ! jump_valid(s) && ! double_jump_valid(s)){        
                board[c][d].add_red_piece();
                if(board[a][b].has_red_king()){
                    board[c][d].set_king();
                }
                board[a][b].set_empty();
            }
            else if(jump_valid(s) && ! double_jump_valid(s)){
                board[c][d].add_red_piece();                
                board[(a + c) / 2][(b + d) / 2].set_empty();
                if(board[a][b].has_red_king()){
                    board[c][d].set_king();
                }
                board[a][b].set_empty();
            }
            else if(double_jump_valid(s)){
                board[c][d].add_red_piece();
                if((c == a - 4) && (d == b)){
                    e = a - 2;
                    f = b - 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);

                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][b - 1].set_empty();
                            board[(a + c) / 2 - 1][b - 1].set_empty();
                        }
                    }
                    else{
                        e = a - 2;
                        f = b + 2;
                        s2 = to_move(a, b, e, f);
                        s3 = to_move(e, f, c, d);

                        if(jump_valid(s2)){
                            if(second_jump_valid(s3)){
                                board[(a + c) / 2 + 1][b + 1].set_empty();
                                board[(a + c) / 2 - 1][b + 1].set_empty();
                            }
                        }
                    }
                    if(board[a][b].has_red_king()){
                        board[c][d].set_king();
                    }
                    board[a][b].set_empty();
                }
                else if((c == a - 4) && (d == b + 4)){

                    e = a - 2;
                    f = b + 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);

                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][(b + d) / 2 - 1].set_empty();
                            board[(a + c) / 2 - 1][(b + d) / 2 + 1].set_empty();
                        }
                    }
                    if(board[a][b].has_red_king()){
                        board[c][d].set_king();
                    }
                    board[a][b].set_empty();
                }
                else if((c == a - 4) && (d == b - 4)){
                    e = a - 2;
                    f = b - 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);
                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][(b + d) / 2 + 1].set_empty();
                            board[(a + c) / 2 - 1][(b + d) / 2 - 1].set_empty();
                        }
                    }
                    if(board[a][b].has_red_king()){
                        board[c][d].set_king();    
                    }
                    board[a][b].set_empty();
                }

                    
                    
            }
        }
    }
    else{
        if(board[a][b].has_black_piece() || board[a][b].has_black_king()){
            if(single_move_valid(s) && ! jump_valid(s)){
                board[c][d].add_black_piece();
                if(board[a][b].has_black_king()){
                    board[c][d].set_king();
                }
                board[a][b].set_empty();
                
            }
            else if(jump_valid(s)){
                board[c][d].add_black_piece();
                board[(a + c) / 2][(b + d) / 2].set_empty();
                if(board[a][b].has_black_king()){
                    board[c][d].set_king();
                }
                board[a][b].set_empty();
            }
            else if(double_jump_valid(s)){
                board[c][d].add_black_piece();
                if((c == a + 4) && (d == b)){
                    e = a + 2;
                    f = b - 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);

                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][b - 1].set_empty();
                            board[(a + c) / 2 - 1][b - 1].set_empty();
                        }
                    }
                    else{
                        e = a + 2;
                        f = b + 2;
                        s2 = to_move(a, b, e, f);
                        s3 = to_move(e, f, c, d);

                        if(jump_valid(s2)){
                            if(second_jump_valid(s3)){
                                board[(a + c) / 2 + 1][b + 1].set_empty();
                                board[(a + c) / 2 - 1][b + 1].set_empty();
                            }
                        }
                    }
                    if(board[a][b].has_black_king()){
                        board[c][d].set_king();
                    }
                    board[a][b].set_empty();
                }
                else if((c == a + 4) && (d == b + 4)){
                    e = a + 2;
                    f = b + 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);

                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][(b + d) / 2 - 1].set_empty();
                            board[(a + c) / 2 - 1][(b + d) / 2 + 1].set_empty();
                        }
                    }
                    if(board[a][b].has_black_king()){
                        board[c][d].set_king();
                    }
                    board[a][b].set_empty();
                }
                else if((c == a + 4) && (d == b - 4)){
                    e = a + 2;
                    f = b - 2;
                    s2 = to_move(a, b, e, f);
                    s3 = to_move(e, f, c, d);
                    if(jump_valid(s2)){
                        if(second_jump_valid(s3)){
                            board[(a + c) / 2 + 1][(b + d) / 2 + 1].set_empty();
                            board[(a + c) / 2 - 1][(b + d) / 2 - 1].set_empty();
                        }
                    }
                    if(board[a][b].has_black_king()){
                        board[c][d].set_king();    
                    }
                    board[a][b].set_empty();
                }
            }
        }
    }

    //kings pieces
    for(int i = 0; i < 8; ++i){
        if(board[0][i].has_red_piece()){
            board[1][i].set_king();
        }
    }
    
    for(int j = 0; j < 8; ++j){
        if(board[7][j].has_black_piece()){
            board[1][j].set_king();
        }
    }

    

    game :: make_move(move);
}

//checks if game is over
bool Checkers :: is_game_over() const{    
    bool no_red = true;
    bool no_black = true;

    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            if(board[i][j].has_red_piece() || board[i][j].has_red_king()){
                no_red = false;
            }
            else if(board[i][j].has_black_piece() || board[i][j].has_black_king()){
                no_black = false;
            }
        }
    }

    if(no_red && no_black){
        return true;
    }
    else{
        return false;
    }
}

//returns pointer to clone
main_savitch_14 :: game* Checkers :: clone() const{
    Checkers* copy = new Checkers(*this);
    return copy;
}


//computes all legal moves
void Checkers :: compute_moves(queue<string>& moves) const{
    string move;
    
    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            for(int k = 0; k < 8; ++k){
                for(int m = 0; m < 8; ++m){
                    move = to_move(i, j, k, m);
                    if(is_legal(move)){
                        moves.push(move);
                    }
                }
            }
        }
    }
}

int Checkers :: evaluate() const{
    return num_black() - num_red();
}


Checkers :: who Checkers :: winning() const{
    if(num_red() > num_black()){
        return HUMAN;
    }
    else{
        return COMPUTER;
    }
}
